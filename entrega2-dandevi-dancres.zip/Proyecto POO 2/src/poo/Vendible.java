/**
 * 
 * @author dandevi
 * @author dancres
 * 
 * Fecha de inicio:24/11/2016
 * 
 * Esta clase define los atributos en común para las clases Producto y Pack
 * Esta clase permite un tratmiento homogeneo de las clases Producto y Pack,dandole las mismas características
 * Elemento puede referirse tanto a un producto como a un pack
 * 
 */

package poo;

public abstract class Vendible {

	public String nombre;
	public String UPC;

	/**
	 * Constructor de Vendible
	 * 
	 * @param precio
	 *            Precio del elemento
	 * @param nombre
	 *            Nombre del elemento
	 * @param UPC
	 *            Codigo universal del elemento
	 */

	public Vendible(String nombre, String UPC) {
		this.nombre = nombre;
		this.UPC = UPC;
	}

	/**
	 * Devuelve el nombre del elemento
	 * 
	 * @return Nombre del elemento
	 */

	public String getNombre() {
		return nombre;
	}

	/**
	 * Fija el nombre del elemento
	 * 
	 * @param nombre
	 *            Nombre del elemento
	 */

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * Devuelve el código de compañia del elemento
	 * 
	 * @param UPC
	 *            Codigo universal del elemento
	 * @return Código de compañia del elemento(tanto para productos como para
	 *         packs)
	 */

	public String getCodigoCompañia() {
		return UPC.substring(0,6);
	}

	/**
	 * Devuelve el UPC del elemento
	 * 
	 * @return Codigo universal del elemento
	 */

	public String getUPC() {
		return UPC;
	}

	/**
	 * Determina el UPC del elemento
	 * 
	 * @param UPC
	 *            Codigo universal del elemento
	 */

	public void setUPC(String UPC) {
		this.UPC = UPC;
	}

}
