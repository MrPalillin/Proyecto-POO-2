/**
 * 
 * @author dandevi
 * @author dancres
 * 
 * Fecha de inicio:24/11/2016
 *
 */

package poo;

public class Producto extends Vendible {

	/**
	 * Atributos de la clase Producto
	 * 
	 * @param precio
	 *            Precio del producto
	 * @param nombre
	 *            Nombre del producto
	 * @param UPC
	 *            Codigo universal del producto
	 * @see Vendible
	 */

	public Producto(float precio, String nombre, String UPC) {
		super(precio, nombre, UPC);
	}

	/**
	 * Devuelve el nombre del producto
	 * 
	 * @return Nombre del producto
	 */

	@Override
	public String getNombre() {
		return nombre;
	}

	/**
	 * Fija el nombre de un producto
	 * 
	 * @param Nombre
	 *            del producto
	 */

	@Override
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * Devuelve el precio del producto
	 * 
	 * @return Precio del producto
	 */

	@Override
	public float getPrecio() {
		return precio;
	}

	@Override
	public void setPrecio(float precio) {
		this.precio = precio;
	}

	/**
	 * Devuelve el codigo de compañia del producto
	 * 
	 * @return Codigo de compañia del producto
	 */

	public String getCodigoCompania() {
		return UPC.substring( 0, 6);
	}

	/**
	 * Devuelve el codigo de producto del producto
	 * 
	 * @return Codigo del producto
	 */

	public String getCodigoProducto() {
		return UPC.substring(6, 11);
	}

	/**
	 * Devuelve el digito de control del producto
	 * 
	 * @return Digito de control del producto
	 */

	public int getDigitoControl(int[] UPC) {
		int s = 0;
		for (int i = 0; i < 11; i++) {
			s = (UPC[i] % 2 == 0) ? s + UPC[i] : s + 3 * UPC[i];
		}
		int m = 0;
		while (s > m) {
			m = m + 10;
		}
		return Math.abs(s - m);
	}

	/**
	 * Devuelve el UPC del producto
	 * 
	 * @return Codigo universal del producto
	 */

	@Override
	public String getUPC() {
		return UPC;
	}

}
