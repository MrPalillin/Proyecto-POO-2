/**
 * 
 * @author dandevi
 * @author dancres
 * 
 * Fecha de inicio:24/11/2016
 * 
 */

package poo;

public class Pack extends Vendible {

	private Producto[] contenido;
	boolean valido;
	
	/**
	 * Características de un pack de productos
	 * 
	 * @param precio
	 *            Precio total del producto(incluye descuento del 20% del total)
	 * @param nombre
	 *            Nombre del pack
	 * @param UPC
	 *            Codigo universal del pack(no de producto)
	 * @param contenido
	 *            Productos del pack
	 * @see Vendible
	 */

	public Pack(Producto[] contenido, String nombre, String UPC, boolean valido) {
		super(nombre, UPC);
		this.contenido = contenido;
	}

	/**
	 * Devuelve el nombre del pack
	 * 
	 * @return Nombre del pack
	 */

	@Override
	public String getUPC() {
		return UPC;
	}
	
	/**
	 * Devuelve el nombre del pack
	 * 
	 */

	@Override
	public String getNombre() {
		return nombre;
	}

	/**
	 * Fija el nombre del pack
	 * 
	 * @param Nombre
	 *            del pack
	 */

	@Override
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * Devuelve el contenido del pack
	 * 
	 * @return Contenido del pack
	 */

	public Producto[] getContenido() {
		return contenido;
	}

	/**
	 * Determina el contenido del pack
	 * 
	 * @param contenido
	 *            Contenido del pack
	 */

	public void setContenido(Producto[] contenido) {
		this.contenido = contenido;
	}

	/**
	 * Devuelve el precio del pack(diferente de Vendible,ya que realiza el
	 * descuento del 20%)
	 * 
	 * @return Precio final del pack
	 */

	public float getPrecio() {
		float precio=0;
		for(int i=0;i<contenido.length;i++) precio=precio+contenido[i].getPrecio();
		return precio*0.8f;//Suma de productos*0.8
	}

	/**
	 * Determina si los productos del pack son diferentes entre si
	 * 
	 * @param contenido
	 *            Contenido del pack
	 * @return Devuelve si se cumple la condicion o no
	 */

	public boolean productosDiferentes() {
		for (int i = 0; i < contenido.length; i++) {
			for (int j = 0; j < contenido.length; j++) {
				if (i != j && contenido[i].equals(contenido[j])) {
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * Calcula el tamaño del pack(nº de elementos) para saber si hay minimo dos
	 * 
	 * @param contenido
	 *            Contenido del pack
	 * @return Devuelve si hay mínino dos productos en el pack o no(no interesa
	 *         el número)
	 */

	public boolean tamañoMinimo() {
		return (contenido.length > 1) ? true : false;
	}

	/**
	 * Determina si el pack es valido o no
	 * 
	 * @return booleano que determina la validez del pack
	 */

	public boolean packValido() {
		return (productosDiferentes() && tamañoMinimo()) ? true : false;
	}

	/**
	 * Devuelve si un producto concreto está en el pack o no
	 * 
	 * @param busqueda
	 *            elemento a buscar
	 * @return Booleano que determina si hay coincidencia o no
	 */

	public boolean contiene(Producto busqueda) {
		for (int i = 0; i < contenido.length; i++) {
			if (contenido[i].equals(busqueda)) {
				return true;
			}
		}
		return false;
	}

}
