/**
 * @author dandevi
 * @author dancres
 */

package poo;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;

public class PackTest {//Preguntar si los productos y el precio se pueden crear fuera de pack

	Producto producto1 = new Producto(2.20f, "Bocadillo", "12345678912");
	Producto producto2 = new Producto(1.50f, "Chocolate", "15935712345");
	Producto producto3 = new Producto(1.50f, "Galletas", "11111111111");
	Producto[] conjunto = { producto1, producto2 };
	Producto[] conjuntoError = { producto1 };
	Producto[] conjuntoIguales = { producto2, producto2 };

	@Test
	public void testGetPrecio() {
		Pack ejemplo = new Pack(conjunto, "Combo", "11144477722",false);
		assertEquals(ejemplo.getPrecio(), 2.96, 1);
	}

	@Test(expected = AssertionError.class)
	public void testGetPrecioError() {
		Pack ejemplo = new Pack(conjunto, "Combo", "11144477722",false);
		assertTrue(ejemplo.getPrecio()==2.50f);		//Debido a un error desconocido,utilizamos otro tipo de assert
	}

	@Test
	public void testGetNombre() {
		Pack ejemplo = new Pack(conjunto, "Combo", "11144477722",false);
		assertEquals(ejemplo.getNombre(), "Combo");
	}

	@Test(expected = AssertionError.class)
	public void testGetNombreError() {
		Pack ejemplo = new Pack(conjunto, "Combo", "11144477722",false);
		assertEquals(ejemplo.getNombre(), "Bocadillo");
	}

	@Test
	public void testGetContenido() {
		Pack ejemplo = new Pack(conjunto, "Combo", "11144477722",false);
		assertTrue(Arrays.equals(ejemplo.getContenido(), conjunto));
	}

	@Test(expected = AssertionError.class)
	public void testGetContenidoError() {
		Pack ejemplo = new Pack(conjunto, "Combo", "11144477722",false);
		assertTrue(Arrays.equals(ejemplo.getContenido(), conjuntoIguales));
	}

	@Test
	public void testGetUPC() {
		Pack ejemplo = new Pack(conjunto, "Combo", "11144477722",false);
		assertEquals(ejemplo.getUPC(), "11144477722");
		assertNotEquals(ejemplo.getUPC(), "12345678912");
	}

	@Test(expected = AssertionError.class)
	public void testGetUPCError() {
		Pack ejemplo = new Pack(conjunto, "Combo", producto1.getUPC(),false);
		assertEquals(ejemplo.getUPC(), "11144477722");
		assertNotEquals(ejemplo.getUPC(), "12345678912");
	}

	@Test
	public void testProductosDiferentes() {
		Pack ejemplo = new Pack(conjunto, "Combo", producto1.getUPC(),false);
		assertTrue(ejemplo.productosDiferentes());
	}

	@Test(expected = AssertionError.class)
	public void testProductosDiferentesError() {
		Pack ejemplo = new Pack(conjuntoIguales, "Combo", producto1.getUPC(),false);
		assertTrue(ejemplo.productosDiferentes());
	}

	@Test
	public void testTamañoMinimo() {
		Pack ejemplo = new Pack(conjuntoIguales, "Combo", producto1.getUPC(),false);
		assertTrue(ejemplo.tamañoMinimo());
	}

	@Test(expected = AssertionError.class)
	public void testTamañoMinimoError() {
		Pack ejemplo = new Pack(conjuntoError, "Combo", producto1.getUPC(),false);
		assertTrue(ejemplo.tamañoMinimo());
	}
	
	@Test
	public void testPackValido() {
		Pack ejemplo = new Pack(conjunto, "Combo", producto1.getUPC(),false);
		assertTrue(ejemplo.packValido());
	}
	
	@Test(expected = AssertionError.class)
	public void testPackValidoErrorTamaño() {
		Pack ejemplo = new Pack(conjuntoError, "Combo", producto1.getUPC(),false);
		assertTrue(ejemplo.packValido());
	}
	
	@Test(expected = AssertionError.class)
	public void testPackValidoErrorIguales() {
		Pack ejemplo = new Pack(conjuntoIguales, "Combo", producto1.getUPC(),false);
		assertTrue(ejemplo.packValido());
	}
	
	@Test
	public void testContiene() {
		Pack ejemplo = new Pack(conjunto, "Combo", producto1.getUPC(),false);
		assertTrue(ejemplo.contiene(producto1));
	}
	
	@Test(expected = AssertionError.class)
	public void testContieneError() {
		Pack ejemplo = new Pack(conjunto, "Combo", producto1.getUPC(),false);
		assertTrue(ejemplo.contiene(producto3));
	}

}
