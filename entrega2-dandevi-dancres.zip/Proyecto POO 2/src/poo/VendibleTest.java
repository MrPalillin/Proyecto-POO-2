/**
 * @author dadnevi
 * @author dancres
 */

package poo;

import static org.junit.Assert.*;

import org.junit.Test;

public abstract class VendibleTest {// Faltan los de pack

	Producto producto1 = new Producto(2.20f, "Bocadillo", "12345678912");
	Producto producto2 = new Producto(1.50f, "Chocolate", "15935712345");
	Producto[] contenido = { producto1, producto2 };

	@Test
	public void NombreTestProducto() {
		Producto ejemplo = new Producto(2.20f, "Patatas de importacion", "123456789123");
		assertTrue(ejemplo.getNombre().equals("Patatas de importacion"));
	}

	@Test(expected = AssertionError.class)
	public void NombreTestErrorProducto() {
		Producto ejemplo = new Producto(2.20f, "Patatas fritas", "123456789123");
		assertTrue(ejemplo.getNombre().equals("123456789123"));
	}

	@Test
	public void NombreTestPack() {
		Pack ejemplo = new Pack(contenido, "Patatas de importacion", "123456789123", true);
		assertTrue(ejemplo.getNombre().equals("Patatas de importacion"));
	}

	@Test(expected = AssertionError.class)
	public void NombreTestErrorPack() {
		Pack ejemplo = new Pack(contenido, "Patatas de importacion", "123456789123", true);
		assertTrue(ejemplo.getNombre().equals("123456789123"));
	}

	@Test
	public void UPCTestProducto() {
		Pack ejemplo = new Pack(contenido, "Patatas de importacion", "123456789123", true);
		String prueba = "123456789123";
		assertSame(prueba, ejemplo.getUPC());
	}

	@Test(expected = AssertionError.class)
	public void UPCTestErrorProducto() {
		Pack ejemplo = new Pack(contenido, "Patatas de importacion", "123456789123", true);
		String prueba = "111222333444";
		assertSame(prueba, ejemplo.getUPC());
	}

	@Test
	public void UPCTestPack() {
		Pack ejemplo = new Pack(contenido, "Patatas de importacion", "123456789123", true);
		String prueba = "123456789123";
		assertSame(prueba, ejemplo.getUPC());
	}

	@Test(expected = AssertionError.class)
	public void UPCTestErrorPack() {
		Pack ejemplo = new Pack(contenido, "Patatas de importacion", "123456789123", true);
		String prueba = "111222333444";
		assertSame(prueba, ejemplo.getUPC());
	}

	@Test
	public void CodigoCompañiaTestProducto() {
		Pack ejemplo = new Pack(contenido, "Patatas de importacion", "123456789123", true);
		assertTrue(ejemplo.getCodigoCompañia().equals("123456"));
	}

	@Test(expected = AssertionError.class)
	public void CodigoCompañiaTestErrorProducto() {
		Pack ejemplo = new Pack(contenido, "Patatas de importacion", "123456789123", true);
		assertTrue(ejemplo.getCodigoCompañia().equals("111222"));
	}

	@Test
	public void CodigoCompañiaTestPack() {
		Pack ejemplo = new Pack(contenido, "Patatas de importacion", "123456789123", true);
		assertTrue(ejemplo.getCodigoCompañia().equals("123456"));
	}

	@Test(expected = AssertionError.class)
	public void CodigoCompañiaTestErrorPack() {
		Pack ejemplo = new Pack(contenido, "Patatas de importacion", "123456789123", true);
		assertTrue(ejemplo.getCodigoCompañia().equals("111222"));
	}
}
