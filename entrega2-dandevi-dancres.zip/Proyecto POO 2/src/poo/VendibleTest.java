/**
 * @author dadnevi
 * @author dancres
 */

package poo;

import static org.junit.Assert.*;

import org.junit.Test;

public abstract class VendibleTest {//Faltan los de pack

	@Test
	public void NombreTestProducto() {
		Producto ejemplo = new Producto(2.20f,"Patatas de importacion", "123456789123");
		assertTrue(ejemplo.getNombre().equals("Patatas de importacion"));
	}

	@Test(expected = AssertionError.class)
	public void NombreTestErrorProducto() {
		Producto ejemplo = new Producto(2.20f,"Patatas fritas", "123456789123");
		assertTrue(ejemplo.getNombre().equals("123456789123"));
	}
	
	@Test
	public void PrecioTestProducto(){
		Producto ejemplo = new Producto(2.20f,"Patatas fritas", "123456789123");
		assertEquals(ejemplo.getPrecio(),2.20,1);
	}
	
	@Test
	public void PrecioTestProductoNulo(){
		Producto ejemplo = new Producto(0.0f,"Patatas fritas", "123456789123");
		assertEquals(ejemplo.getPrecio(),0.0,1);
	}
	
	@Test(expected=AssertionError.class)
	public void PrecioTestProductoError(){
		Producto ejemplo = new Producto(1.50f,"Patatas fritas", "123456789123");
		assertEquals(ejemplo.getPrecio(),2.20,1);
	}

	@Test
	public void UPCTestProducto() {
		Producto ejemplo = new Producto(2.20f,"Patatas de importacion", "123456789123");
		String prueba = "123456789123";
		assertSame(prueba, ejemplo.getUPC());
	}

	@Test(expected = AssertionError.class)
	public void UPCTestErrorProducto() {
		Producto ejemplo = new Producto(2.20f,"Patatas de importacion", "123456789123");
		String prueba = "111222333444";
		assertSame(prueba, ejemplo.getUPC());
	}

	@Test
	public void CodigoCompañiaTestProducto() {
		Producto ejemplo = new Producto(2.20f,"Patatas de importacion", "123456789123");
		assertTrue(ejemplo.getCodigoCompañia().equals("123456"));
	}

	@Test(expected = AssertionError.class)
	public void CodigoCompañiaTestErrorProducto() {
		Producto ejemplo = new Producto(2.20f,"Patatas de importacion", "123456789123");
		assertTrue(ejemplo.getCodigoCompañia().equals("111222"));
	}
}
