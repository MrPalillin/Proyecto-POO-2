/**
 * @author dadnevi
 * @author dancres
 */

package poo;

import static org.junit.Assert.*;

import org.junit.Test;

public class VendibleTest {

	@Test
	public void PrecioCorrecto() {
		Vendible ejemplo = new Vendible(2.50f, "Patatas de importacion", "123456789123");
		assertTrue(ejemplo.getPrecio() >= 0.0);
	}

	@Test(expected = AssertionError.class)
	public void PrecioIncorrecto() {
		Vendible ejemplo = new Vendible(-2.50f, "Patatas de importacion", "123456789123");
		assertTrue(ejemplo.getPrecio() >= 0.0);
	}

	@Test
	public void NombreTest() {
		Vendible ejemplo = new Vendible(2.50f, "Patatas de importacion", "123456789123");
		assertTrue(ejemplo.getNombre().equals("Patatas de importacion"));
	}

	@Test(expected = AssertionError.class)
	public void NombreTestError() {
		Vendible ejemplo = new Vendible(2.50f, "Patatas fritas", "123456789123");
		assertTrue(ejemplo.getNombre().equals("123456789123"));
	}

	@Test
	public void UPCTest() {
		Vendible ejemplo = new Vendible(2.50f, "Patatas de importacion", "123456789123");
		String prueba = "123456789123";
		assertSame(prueba, ejemplo.getUPC());
	}

	@Test(expected = AssertionError.class)
	public void UPCTestError() {
		Vendible ejemplo = new Vendible(2.50f, "Patatas de importacion", "123456789123");
		String prueba = "111222333444";
		assertSame(prueba, ejemplo.getUPC());
	}

	@Test
	public void CodigoCompañiaTest() {
		Vendible ejemplo = new Vendible(2.50f, "Patatas de importacion", "123456789123");
		assertTrue(ejemplo.getCodigoCompañia().equals("123456"));
	}

	@Test(expected = AssertionError.class)
	public void CodigoCompañiaTestError() {
		Vendible ejemplo = new Vendible(2.50f, "Patatas de importacion", "123456789123");
		assertTrue(ejemplo.getCodigoCompañia().equals("111222"));
	}
}
