/**
 * 
 * @author dandevi
 * @author dancres
 * 
 * Fecha de inicio:24/11/2016
 *
 */

package poo;

import java.util.Arrays;
import poo.Vendible;

public class Producto extends Vendible{


	public Producto(float precio, String nombre, int[] UPC) {
		super(precio, nombre, UPC);
	}
	
	@Override
	public String getNombre() {
		return nombre;
	}

	@Override
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public float getPrecio() {
		return precio;
	}

	@Override
	public void setPrecio(float precio) {
		this.precio = precio;
	}

	public int[] getCodigoCompania(int[] UPC) {
		return Arrays.copyOfRange(UPC, 0, 5);
	}

	public int[] getCodigoProducto() {
		return Arrays.copyOfRange(UPC, 6, 10);
	}

	public int getDigitoControl(int[] UPC) {
		int s = 0;
		for (int i = 0; i < 11; i++) {
			s = (UPC[i] % 2 == 0) ? s + UPC[i] : s + 3 * UPC[i];
		}
		int m = 0;
		while (s > m) {
			m = m + 10;
		}
		return Math.abs(s - m);
	}

	public int[] getUPC() {
		return UPC;
	}

	public void setUPC(int[] UPC) {
		this.UPC = UPC;
	}

}
