/**
 * 
 * @author dandevi
 * 
 * Fecha de inicio:24/11/2016
 *
 */

package poo;

import java.util.Arrays;

public class Producto {

	private String nombre;
	private float precio;
	private int[] codigoCompania;
	private int[] codigoProducto;
	private int digitoControl;
	private int[] UPC;

	public Producto(String nombre, float precio, int[] UPC) {

		this.nombre = nombre;
		this.precio = precio;
		this.UPC = UPC;
		this.codigoCompania = Arrays.copyOfRange(UPC, 0, 5);
		this.codigoProducto = Arrays.copyOfRange(UPC, 6, 10);
		this.digitoControl = control(UPC);

	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public float getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		this.precio = precio;
	}

	public int[] getCodigoCompania() {
		return codigoCompania;
	}

	public void setCodigoCompania(int[] codigoCompania) {
		this.codigoCompania = codigoCompania;
	}

	public int[] getCodigoProducto() {
		return codigoProducto;
	}

	public void setCodigoProducto(int[] codigoProducto) {
		this.codigoProducto = codigoProducto;
	}

	public int getDigitoControl() {
		return digitoControl;
	}

	public void setDigitoControl(int digitoControl) {
		this.digitoControl = digitoControl;
	}

	public int[] getUPC() {
		return UPC;
	}

	public void setUPC(int[] uPC) {
		UPC = uPC;
	}

	private int control(int[] UPC) {
		int s = 0;
		for (int i = 0; i < 11; i++) {
			s = (UPC[i] % 2 == 0) ? s + UPC[i] : s + 3 * UPC[i];
		}
		int m = 0;
		while (s > m) {
			m = m + 10;
		}
		return Math.abs(s - m);
	}

}
