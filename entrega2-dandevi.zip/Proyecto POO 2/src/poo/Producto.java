/**
 * 
 * @author dandevi
 * 
 * Fecha de inicio:24/11/2016
 *
 */

package poo;

import java.util.Arrays;

public class Producto {

	private String nombre;
	private float precio;
	private int[] UPC;

	public Producto(String nombre, float precio, int[] UPC) {

		this.nombre = nombre;
		this.precio = precio;
		this.UPC = UPC;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public float getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		this.precio = precio;
	}

	public int[] getCodigoCompania(int[] UPC) {
		return Arrays.copyOfRange(UPC, 0, 5);
	}

	public int[] getCodigoProducto() {
		return Arrays.copyOfRange(UPC, 6, 10);
	}

	public int getDigitoControl(int[] UPC) {
		int s = 0;
		for (int i = 0; i < 11; i++) {
			s = (UPC[i] % 2 == 0) ? s + UPC[i] : s + 3 * UPC[i];
		}
		int m = 0;
		while (s > m) {
			m = m + 10;
		}
		return Math.abs(s - m);
	}

	public int[] getUPC() {
		return UPC;
	}

	public void setUPC(int[] uPC) {
		UPC = uPC;
	}

}
