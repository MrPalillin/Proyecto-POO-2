/**
 * @author dandevi
 * @author dancres
 */
package poo;

import static org.junit.Assert.*;

import org.junit.Test;

public class ProductoTest {

	@Test
	public void testGetPrecio() {
		Producto ejemplo = new Producto(0.0f, "Bocadillo jamon", "15935712345");
		assertTrue(ejemplo.getPrecio() >= 0.0);
	}

	@Test(expected = AssertionError.class)
	public void testGetPrecioError() {
		Producto ejemplo = new Producto(-1.50f, "Bocadillo jamon", "15935712345");
		assertTrue(ejemplo.getPrecio() >= 0.0);
	}

	@Test
	public void testGetNombre() {
		Producto ejemplo = new Producto(-1.50f, "Bocadillo jamon", "15935712345");
		assertEquals(ejemplo.getNombre(), "Bocadillo jamon");
	}

	@Test(expected = AssertionError.class)
	public void testGetNombreError() {
		Producto ejemplo = new Producto(-1.50f, "Bocadillo jamon", "15935712345");
		assertEquals(ejemplo.getNombre(), "Bocadillo chocolate");
	}

	@Test
	public void testGetUPC() {
		Producto ejemplo = new Producto(3.25f, "Bocadillo jamon", "15935712345");
		assertEquals(ejemplo.getUPC(), "15935712345");
	}

	@Test(expected = AssertionError.class)
	public void testGetUPCError() {
		Producto ejemplo = new Producto(3.25f, "Bocadillo jamon", "15935712345");
		assertEquals(ejemplo.getUPC(), "111222333444");
	}

	@Test
	public void testGetCodigoCompania() {
		Producto ejemplo = new Producto(3.25f, "Bocadillo jamon", "15935712345");
		assertEquals(ejemplo.getCodigoCompania(), "159357");
	}

	@Test(expected = AssertionError.class)
	public void testGetCodigoCompaniaError() {
		Producto ejemplo = new Producto(3.25f, "Bocadillo jamon", "15935712345");
		assertEquals(ejemplo.getCodigoCompania(), "123456");
	}

	@Test
	public void testGetCodigoProducto() {
		Producto ejemplo = new Producto(3.25f, "Bocadillo jamon", "15935712345");
		assertEquals(ejemplo.getCodigoProducto(), "12345");
	}

	@Test(expected = AssertionError.class)
	public void testGetCodigoProductoError() {
		Producto ejemplo = new Producto(3.25f, "Bocadillo jamon", "15935712345");
		assertEquals(ejemplo.getCodigoProducto(), "15935");
	}

	@Test
	public void testGetDigitoControl() {
		Producto ejemplo = new Producto(3.05f, "Bocadillo", "12345678913");
		int[] prueba = new int[11];
		String[] division = ejemplo.getUPC().split("");
		for (int i = 0; i < ejemplo.getUPC().length(); i++)
			prueba[i] = Integer.parseInt(division[i]);
		int s = 0;
		for (int i = 0; i < 11; i++) {
			s = (prueba[i] % 2 == 0) ? s + prueba[i] : s + 3 * prueba[i];
		}
		int m = 0;
		while (s > m) {
			m = m + 10;
		}
		assertEquals(Math.abs(s - m), 3);
	}

	@Test(expected = AssertionError.class)
	public void testGetDigitoControlError() {
		Producto ejemplo = new Producto(3.05f, "Bocadillo", "12345678913");
		int[] prueba = new int[11];
		String[] division = ejemplo.getUPC().split("");
		for (int i = 0; i < ejemplo.getUPC().length(); i++)
			prueba[i] = Integer.parseInt(division[i]);
		int s = 0;
		for (int i = 0; i < 11; i++) {
			s = (prueba[i] % 2 == 0) ? s + prueba[i] : s + 3 * prueba[i];
		}
		int m = 0;
		while (s > m) {
			m = m + 10;
		}
		assertEquals(Math.abs(s - m), 0);
	}
}