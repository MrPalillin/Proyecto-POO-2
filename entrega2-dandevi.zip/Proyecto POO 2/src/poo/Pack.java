/**
 * 
 * @author dandevi
 * 
 * Fecha de inicio:24/11/2016
 * 
 */


package poo;

public class Pack {
	
	private String nombre;
	private Producto[] contenido;
	private float precio;
	
	public Pack(String nombre,Producto[] contenido,float precio){
		this.nombre=nombre;
		this.contenido=contenido;
		this.precio=precio;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Producto[] getContenido() {
		return contenido;
	}

	public void setContenido(Producto[] contenido) {
		this.contenido = contenido;
	}

	public float getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		this.precio = precio;
	}

}
