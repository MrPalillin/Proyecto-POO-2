/**
 * 
 * @author dandevi
 * @author dancres
 * 
 * Fecha de inicio:24/11/2016
 * 
 */


package poo;

import java.util.Arrays;

public class Pack extends Vendible{
	
	private Producto[] contenido;
	
	public Pack(float precio,String nombre,int[] UPC,Producto[] contenido){
		super(precio,nombre,UPC);
		this.contenido=contenido;
	}
	
	
	@Override
	public String getNombre() {
		return nombre;
	}

	@Override
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Producto[] getContenido() {
		return contenido;
	}

	public void setContenido(Producto[] contenido) {
		this.contenido = contenido;
	}

	@Override
	public float getPrecio() {
		return precio;
	}

	@Override
	public void setPrecio(float precio) {
		this.precio = precio*0.8f;
	}
	
	public boolean productosDiferentes(Producto[] contenido){
		for(int i=0;i<contenido.length;i++){
			for(int j=0;j<contenido.length;j++){
				if(i!=j && Arrays.equals(contenido[i].getUPC(), contenido[j].getUPC())){
					return false;
				}
			}
		}
		return true;
	}
	
	public boolean tamañoMinimo(Producto[] contenido){
		return (contenido.length>1) ? true : false;
	}

}
