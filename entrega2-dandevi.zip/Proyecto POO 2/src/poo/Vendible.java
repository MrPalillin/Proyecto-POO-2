/**
 * 
 * @author dandevi
 * 
 * Fecha de inicio:24/11/2016
 * 
 */

package poo;

import java.util.Arrays;

public class Vendible {
	
	public Object tipo;
	public float precio;
	public String nombre;
	public int[] UPC;

	public Vendible(Object tipo,float precio,String nombre,int[] UPC){
		this.nombre=nombre;
		this.tipo=tipo;
		this.precio=precio;
		this.UPC=UPC;
		
	}

	public Object getTipo() {
		return tipo;
	}

	public void setTipo(Object tipo) {
		this.tipo = tipo;
	}

	public float getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		this.precio = precio;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int[] getCodigoCompañia(int[] UPC){
		return Arrays.copyOfRange(UPC, 0, 5);
	}
	
}
