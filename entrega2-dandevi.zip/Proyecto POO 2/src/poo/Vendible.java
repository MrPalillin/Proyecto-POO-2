/**
 * 
 * @author dandevi
 * @author dancres
 * 
 * Fecha de inicio:24/11/2016
 * 
 * Esta clase define los atributos en común para las clases Producto y Pack
 * Esta clase permite un tratmiento homogeneo de las clases Producto y Pack,dandole las mismas características
 * 
 */

package poo;

import java.util.Arrays;

public class Vendible{
	
	public float precio;
	public String nombre;
	public int[] UPC;
	
	/**
	 * 
	 * Constructor de Vendible
	 * 
	 * @param precio Precio del elemento
	 * @param nombre Nombre del elemento
	 * @param UPC Codigo universal del elemento
	 */

	public Vendible(float precio,String nombre,int[] UPC){
		this.nombre=nombre;
		this.precio=precio;
		this.UPC=UPC;
	}
	
	/**
	 * Devuelve el precio del elemento
	 * @return Precio del elemento
	 */

	public float getPrecio() {
		return precio;
	}

	/**
	 * Fija el precio del elemento
	 * @param precio Precio del elemento
	 */
	
	public void setPrecio(float precio) {
		this.precio = precio;
	}
	
	/**
	 * Devuelve el nombre del elemento
	 * @return Nombre del elemento
	 */

	public String getNombre() {
		return nombre;
	}

	/**
	 * Fija el nombre del elemento
	 * @param nombre Nombre del elemento
	 */
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	/**
	 * Devuelve el código de compañia del elemento(primeros 6 dígitos del UPC)
	 * @param UPC Codigo universal del elemento
	 * @return Código de compañia del elemento(tanto para productos como para packs)
	 */
	
	public int[] getCodigoCompañia(int[] UPC){
		return Arrays.copyOfRange(UPC, 0, 5);
	}
	
}
