/**
 * 
 * @author daniel dandevi
 * 
 * Fecha de inicio:24/11/2016
 * 
 */


package poo;

public class Vendible {
	
	public Vendible(){
		
	}

}
