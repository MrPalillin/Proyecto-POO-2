/**
 * 
 * @author dandevi
 * 
 * Fecha de inicio:24/11/2016
 * 
 */

package poo;

public class Vendible {

	private boolean vender;
	private String nombre;
	private float precio;
	private int[] UPC;

	public Vendible(boolean vender, String nombre, float precio, int[] UPC) {
		this.vender = vender;
		this.nombre = nombre;
		this.precio = precio;
		this.UPC = UPC;

	}

	public boolean getVender() {
		return vender;
	}

	public void setVender(boolean vender) {
		this.vender = vender;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public float getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		this.precio = precio;
	}

	public int[] getUPC() {
		return UPC;
	}

	public void setUPC(int[] uPC) {
		UPC = uPC;
	}

}
