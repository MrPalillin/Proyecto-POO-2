/**
 * @author dandevi
 * @author dancres
 */

package poo;

import static org.junit.Assert.*;

import org.junit.Test;

public class PackTest {

	Producto producto1 = new Producto(2.20f, "Bocadillo", "12345678912");
	Producto producto2 = new Producto(1.50f, "Chocolate", "15935712345");
	Producto[] conjunto = { producto1, producto2 };

	@SuppressWarnings("null") // Debe haber otra forma de coger el precio total
	@Test
	public void testGetPrecio() {
		Pack ejemplo = null;
		ejemplo = new Pack(conjunto, ejemplo.calculaPrecio(conjunto), "Combo", "11144477722");
		assertEquals(ejemplo.getPrecio(), 2.96f, 1);
	}

	@Test
	public void testGetNombre() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetContenido() {
		fail("Not yet implemented");
	}

	@Test
	public void testProductosDiferentes() {
		fail("Not yet implemented");
	}

	@Test
	public void testTamañoMinimo() {
		fail("Not yet implemented");
	}

}
